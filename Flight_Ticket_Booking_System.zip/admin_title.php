<div class="topbar">
    <div class="toggle">
        <a href="#"><ion-icon name="menu-outline"></ion-icon></a>
    </div>

    <div class="search">
        <h3>Welcome, <?php echo $_SESSION['admin_name']; ?></h3>
    </div>
    <div class="user">
        <!-- <ion-icon name="people-outline"></ion-icon> -->

        <img src="imgs/people.png" alt="">
    </div>
</div>